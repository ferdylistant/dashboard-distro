<?php
/*
 * This file is included by composer automatically and is used simply
 * to define a parameter that allows the Editor PHP libraries to load
 * (they check for this parameter and will exit immediately if not
 * defined for security).
 * 
 * This file should NOT be included manually. It is for use by
 * composer only.
 */

define("DATATABLES", true);
