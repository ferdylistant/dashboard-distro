Select l.name, count(s.id) as total_student from lesson l
left join lesson_student sl on l.id = sl.lesson_id
left join student s on sl.student_id = s.id
group by l.id
order by total_student desc;
