Select room.room, l.duration * s.id as crowd_level from room
left join lesson_room lr on room.id = lr.room_id
left join lesson l on lr.lesson_id = l.id
left join lesson_student ls on l.id = ls.lesson_id
left join student s on ls.student_id = s.id
order by crowd_level desc;
