<?php

// University Student Problem
// ================================================

// Description
// ================================================
// Create a program that simulate student KRS activity, with these following criteria
// a. Student can take lessons
// b. Student can get summary of lessons taken


// Instruction
// ================================================
// 1. Do not modify the code in "Input" block.
// 2. Write codes that match the Output provided in "Output" block
// 3. Write your code in "Solution" block, continue the existing class and method
// 4. Do not modify the provided code
// 5. Click "RUN" to display your solution in "Output" panel



// Input
// ================================================
// A
$student = new Student;
$student->takeLesson('Algorithm and Programming');

$student->getLessonSummary();

// B
$student = new Student;
$student->takeLesson('Artificial Intelligence');
$student->takeLesson('Data Structure 2');

$student->getLessonSummary();

// C
$student = new Student;
$student->takeLesson('Algorithm and Programming');
$student->takeLesson('Advanced Database');
$student->takeLesson('Artificial Intelligence');
$student->takeLesson('Data Structure 2');

$student->getLessonSummary();

// Output
// ================================================

// Name: YOUR_NAME
// Lesson: Algorithm and Programming
// Total duration: 3 SKS
// Room: A17
// Lecturer: Ikhsan Permadi
// Day: Monday, Thursday
// Building: South Block


// Name: YOUR_NAME
// Lesson: Artificial Intelligence, Data Structure 2
// Total duration: 5 SKS
// Room: B12, B10
// Lecturer: Ikhsan Permadi, Faisal Sulhan
// Day: Thursday, Wednesday
// Building: North Block


// Name: YOUR_NAME
// Lesson: Algorithm and Programming, Advanced Database, Artificial Intelligence, Data Structure 2
// Total duration: 12 SKS
// Room: A17, B12, B10
// Lecturer: Ikhsan Permadi, Faisal Sulhan
// Day: Monday, Thursday, Tuesday, Wednesday
// Building: South Block, North Block

// Solution
// ================================================


// START OF PROVIDED CODE
// DO NOT CHANGE CODES IN THIS BLOCK
// ================================================

class Lesson
{
    public function getDetail($lessonName)
    {
        $details = [
            [
                'name' => 'Algorithm and Programming',
                'lecturer' => 'Ikhsan Permadi',
                'room' => 'A17',
                'schedule' => [
                    [
                        'day'=> 'Monday',
                        'duration'=> '2 SKS'
                    ],
                    [
                        'day'=> 'Thursday',
                        'duration'=> '1 SKS'
                    ]
                ]
            ],
            [
                'name' => 'Advanced Database',
                'lecturer' => 'Faisal Sulhan',
                'room' => 'B12',
                'schedule' => [
                    [
                        'day'=> 'Tuesday',
                        'duration'=> '2 SKS'
                    ],
                    [
                        'day'=> 'Thursday',
                        'duration'=> '2 SKS'
                    ]
                ]
            ],
            [
                'name' => 'Artificial Intelligence',
                'lecturer' => 'Ikhsan Permadi',
                'room' => 'B12',
                'schedule' => [
                    [
                        'day'=> 'Thursday',
                        'duration'=> '3 SKS'
                    ]
                ]
            ],
            [
                'name' => 'Data Structure 2',
                'lecturer' => 'Faisal Sulhan',
                'room' => 'B10',
                'schedule' => [
                    [
                        'day'=> 'Wednesday',
                        'duration'=> '2 SKS'
                    ]
                ]
            ],
        ];

        foreach ($details as $key => $detail) {
            if ($detail['name'] == $lessonName) {
                return $details[$key];
            }
        }
    }
}

class Room
{
    public function getBuilding($roomName)
    {
        $details = [
            'A17' => 'South Block',
            'B12' => 'North Block',
            'B10' => 'North Block'
        ];

        sleep(2);

        return $details[$roomName];
    }
}

// END OF PROVIDED CODE
// PLEASE WRITE AND COMPLETE THE CODE BELOW
// ================================================

class Student
{
    private $lessons = [];
    public function takeLesson($lessonName)
    {
        $lessons = new Lesson;
        $rooms = new Room;
        $summary = [];
        foreach ($this->lessons as $lesson) {
            $detail = $lessons->getDetail($lesson);
            $building = $rooms->getBuilding($detail['room']);
            $summary[] = [
                'name' => $detail['name'],
                'room' => $detail['room'],
                'lecturer' => $detail['lecturer'],
                'day' => $detail['schedule'][0]['day'],
                'building' => $building
            ];

        }
        return $summary;

    }

    public function getLessonSummary()
    {
        $lessons = new Lesson;
        $rooms = new Room;
        $summary = [];
        foreach ($this->lessons as $lesson) {
            $detail = $lessons->getDetail($lesson);
            $building = $rooms->getBuilding($detail['room']);
            $summary[] = [
                'name' => $detail['name'],
                'room' => $detail['room'],
                'lecturer' => $detail['lecturer'],
                'day' => $detail['schedule'][0]['day'],
                'building' => $building
            ];

        }
        return $summary;
    }

}

?>
