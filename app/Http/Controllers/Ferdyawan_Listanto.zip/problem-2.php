<?php

// Purchasing problem
// ================================================

// Description
// ================================================
// Create a program that counts the final price of purchase, with these following criteria
// a. 5% discount if total purchase under 1.000.000.
// b. 6.5% discount if total purchase more than or equal to 1.000.000.
// c. Total discount can’t be bigger than 100.000.
// d. 10% tax.
// e. The program accepts total purchase (integer) as an input, and return the final payment (integer).


// Instruction
// ================================================
// 1. Do not modify the code in "Input" block.
// 2. Write codes that match the Output provided in "Output" block
// 3. Write your code in "Solution" block, continue the existing class and method
// 4. Click "RUN" to display your solution in "Output" panel



// Input
// ================================================
$calculator = new PurchaseCalculator;
$calculator->getFinalPrice(5000);
$calculator->getFinalPrice(10000000);

// Output
// ================================================
// 5225
// 10890000
// etc... (We will use another input to validate)


// Solution
// ================================================
class PurchaseCalculator
{
    public function getFinalPrice($purchase)
    {
        $discount = 0;
        $tax = 0;
        $finalPrice = 0;
        if ($purchase < 1000000) {
            $discount = $purchase * 0.055;
        } else {
            $discount = 100000;
        }
        if ($discount > 100000) {
            $discount = 100000;
        }
        $tax = $purchase * 0.1;
        $finalPrice = $purchase - $discount + $tax;
        echo'<br>';
        echo $finalPrice;
    }
}

?>
